#ifndef BASEP_H
#define BASEP_H

#include <QWidget>
#include <QStackedWidget>
#include <QLineEdit>
#include <QListWidget>
#include <QLabel>
#include <QPushButton>

class BasePage : public QWidget
{
    Q_OBJECT
public:
    explicit BasePage(QStackedWidget* stack,QWidget *parent = nullptr);
protected:
    QStackedWidget* stack;
    void addStyledButton(QPushButton* btn,  QString const & color);
signals:
};

#endif // BASEP_H
