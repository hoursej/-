#ifndef MONSTER_H
#define MONSTER_H
#include <QDebug>

class Monster//后续可能加上各种怪物
{

public:
    Monster();

    int getHp();
    int getAttackPower();
    void injured(int a);//////
private:
    int e_Hp;
    int e_AttackPower;
};


#endif // MONSTER_H
