#ifndef USERMANAGER_H
#define USERMANAGER_H

#include <QObject>
#include <QSqlDatabase>
#include <QSqlQuery>

class UserManager:public QObject
{
    Q_OBJECT
public:
    explicit UserManager(QObject *parent = nullptr);
    bool initDatabase();
    bool createUserTable();
    bool addUser(const QString &name, const QString &password, int totalwords);
    bool incrementLearnDays(int userId);
    bool updateWordsLearned(int userId, int newWords);
    QSqlDatabase getdb()const;
    QVariantMap getUserInfo(int userId);
private:
    QSqlDatabase db;
};

#endif // USERMANAGER_H
