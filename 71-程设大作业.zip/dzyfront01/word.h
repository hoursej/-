#ifndef WORD_H
#define WORD_H

#include <QString>
#include <QMediaPlayer>
#include<QAudioOutput>
enum WordStatus
{
    Killed,
    NotKilled
};

class Word {
public:
    Word(const QString& english, const QString& chinese, const QString& pronunciation,
         const QString& audiopath,WordStatus status);

    QString english() const;//返回英文
    QString chinese() const;//返回中文
    QString pronunciation() const;//返回音标
    QString audiofile() const;//返回音频文件路径
    //    QString imagefile()const;
    WordStatus status()const;//返回单词状态
    void playAudio();//播放音频
    static QMediaPlayer *player;
    static QAudioOutput *audioOutput;
    static void initPlayer();//初始化播放器

private:
    QString m_english;
    QString m_chinese;
    QString m_pronunciation;
    QString m_audiofile;
    //    QString m_imagefile;
    WordStatus m_status;
};

#endif // WORD_H
