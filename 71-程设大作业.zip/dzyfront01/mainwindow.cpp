#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "monster.h"
#include "player.h"
#include <QDebug>
using namespace std;



MainWindow::MainWindow(QStackedWidget* stack, QWidget* parent)
    : BasePage(stack,parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    ui->mPB->setValue(Me.getHp());
    ui->ePB->setValue(monster.getHp());
}



MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::setQLab_name(QString Lab_name)//题目单词是一个lable  设置lable文本
{
    ui->QLab->setText(Lab_name);
}
void MainWindow::setABtn_name(QString Btn_name)//按钮的文本作为选项 ABtn 是A选项的按钮
{
    ui->ABtn->setText(Btn_name);
}
void MainWindow::setBBtn_name(QString Btn_name)
{
    ui->BBtn->setText(Btn_name);
}
void MainWindow::setCBtn_name(QString Btn_name)
{
    ui->CBtn->setText(Btn_name);
}
void MainWindow::setDBtn_name(QString Btn_name)
{
    ui->DBtn->setText(Btn_name);
}



//


//
void MainWindow::setButtonColor(QPushButton *btn,const QString &color)//点击选项后根据正误变色
{
    if(color.isEmpty())
    {
        btn->setStyleSheet("");
    }
    else
    {
        btn->setStyleSheet(QString("background-color:%1;co;or:white;").arg(color));
    }
}



void MainWindow::on_ABtn_clicked()
{
    //ui->ABtn->setText("我被点击了！"); dubug
    QPushButton *clickedBtn=qobject_cast<QPushButton*>(sender());
    if(!clickedBtn)
    {
        return;
    }
    bool isCorrect=(clickedBtn->text()=="苹果");//此处应该改为题目对应的正确中文
    if(isCorrect)//玩家选对了
    {
        //怪物受到等同于玩家攻击力的伤害
        if(ui->ePB->value()>Me.getAttackPower())//PB即progress bar //e代表敌人
        {
            ui->ePB->setValue(ui->ePB->value()-Me.getAttackPower());
            qDebug()<<"怪物受伤";
        }
        else if(ui->ePB->value()<=Me.getAttackPower())
        {
            ui->ePB->setValue(0);
            qDebug()<<"怪物死亡";
        }
        setButtonColor(clickedBtn,"green");//按钮变绿
    }
    else//玩家选错了
    {
        //玩家受到等同于怪物攻击力的伤害
        if(ui->mPB->value()>monster.getAttackPower())
        {
            ui->mPB->setValue(ui->mPB->value()-monster.getAttackPower());
            qDebug()<<"玩家受伤";
        }
        else if(ui->mPB->value()<=monster.getAttackPower())
        {
            ui->mPB->setValue(0);
            qDebug()<<"玩家死亡";
        }
        setButtonColor(clickedBtn,"red");//按钮变红
    }

}


void MainWindow::on_BBtn_clicked()
{
    QPushButton *clickedBtn=qobject_cast<QPushButton*>(sender());
    if(!clickedBtn)
    {
        return;
    }
    bool isCorrect=(clickedBtn->text()=="苹果");//改
    if(isCorrect)
    {
        //Ryn.injured(10);
        if(ui->ePB->value()>Me.getAttackPower())
        {
            ui->ePB->setValue(ui->ePB->value()-Me.getAttackPower());
            qDebug()<<"怪物受伤";
        }
        else if(ui->ePB->value()<=Me.getAttackPower())
        {
            ui->ePB->setValue(0);
            qDebug()<<"怪物死亡";
        }
        setButtonColor(clickedBtn,"green");
    }
    else
    {
        //Me.injured(10);
        if(ui->mPB->value()>monster.getAttackPower())
        {
            ui->mPB->setValue(ui->mPB->value()-monster.getAttackPower());
            qDebug()<<"玩家受伤";
        }
        else if(ui->mPB->value()<=monster.getAttackPower())
        {
            ui->mPB->setValue(0);
            qDebug()<<"玩家死亡";
        }
        setButtonColor(clickedBtn,"red");
    }

}


void MainWindow::on_CBtn_clicked()
{
    QPushButton *clickedBtn=qobject_cast<QPushButton*>(sender());
    if(!clickedBtn)
    {
        return;
    }
    bool isCorrect=(clickedBtn->text()=="苹果");//改
    if(isCorrect)
    {
        //Ryn.injured(10);
        if(ui->ePB->value()>Me.getAttackPower())
        {
            ui->ePB->setValue(ui->ePB->value()-Me.getAttackPower());
            qDebug()<<"怪物受伤";
        }
        else if(ui->ePB->value()<=Me.getAttackPower())
        {
            ui->ePB->setValue(0);
            qDebug()<<"怪物死亡";
        }
        setButtonColor(clickedBtn,"green");
    }
    else
    {
        //Me.injured(e_ptr->getAttackPower());
        if(ui->mPB->value()>monster.getAttackPower())
        {
            ui->mPB->setValue(ui->mPB->value()-monster.getAttackPower());
            qDebug()<<"玩家受伤";
        }
        else if(ui->mPB->value()<=monster.getAttackPower())
        {
            ui->mPB->setValue(0);
            qDebug()<<"玩家死亡";
        }
        setButtonColor(clickedBtn,"red");
    }

}


void MainWindow::on_DBtn_clicked()
{
    QPushButton *clickedBtn=qobject_cast<QPushButton*>(sender());
    if(!clickedBtn)
    {
        return;
    }
    bool isCorrect=(clickedBtn->text()=="苹果");//改
    if(isCorrect)
    {
        //Ryn.injured(10);
        if(ui->ePB->value()>Me.getAttackPower())
        {
            ui->ePB->setValue(ui->ePB->value()-Me.getAttackPower());
            qDebug()<<"怪物受伤";
        }
        else if(ui->ePB->value()<=Me.getAttackPower())
        {
            ui->ePB->setValue(0);
            qDebug()<<"怪物死亡";
        }
        setButtonColor(clickedBtn,"green");
    }
    else
    {
        //Me.injured(10);
        if(ui->mPB->value()>monster.getAttackPower())
        {
            ui->mPB->setValue(ui->mPB->value()-monster.getAttackPower());
            qDebug()<<"玩家受伤";
        }
        else if(ui->mPB->value()<=monster.getAttackPower())
        {
            ui->mPB->setValue(0);
            qDebug()<<"玩家死亡";
        }
        setButtonColor(clickedBtn,"red");
    }

}




