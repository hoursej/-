#ifndef PROGRESSP_H
#define PROGRESSP_H

#include "basep.h"
#include "word.h"
#include "usermanager.h"
#include <QLabel>

class ProgressPage : public BasePage {
    Q_OBJECT
public:
    explicit ProgressPage(QStackedWidget* stack, int userId,QWidget* parent = nullptr);
    void loadBook(const QString& filepath);
    void updateProgressLabel();
    void updateBookTitle(const QString& name);
    bool isWordListEmpty() const;
    void initialCount();

private:
    int userID;
    UserManager *um;
    QLabel* bookTitle;
    QLabel* progressLabel;
    QLabel* currentWord;
    QLabel* phonetic;
    QLabel* meaning;
    QLabel* example;
    QVector<Word> words;
    QVector<Word> knownWords;
    QVector<Word> unknownWords;
    QString currentBookFile;

    void loadNextWord();
    void loadLastWord();
    int count;
signals:
};

#endif // PROGRESSP_H
