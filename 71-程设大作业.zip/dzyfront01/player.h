#ifndef PLAYER_H
#define PLAYER_H
#include <QDebug>

class Player//目前还很粗糙 武器暂时没用
{
    enum Weapon
    {
        sword,
        weapon_num
    };
private:
    int m_Hp;//生命值
    Weapon m_weapon;//武器
    int m_AttackPower;//攻击力
public:
    Player();
    int getAttackPower();
    int getHp();

};

#endif // PLAYER_H
