#include "selectp.h"
#include "statsp.h"
#include "loginp.h"
#include "progressp.h"
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QLabel>
#include <QPushButton>
#include <QListWidget>
#include <QProgressBar>
#include <QMessageBox>

SelectionPage::SelectionPage(QStackedWidget* stack,const int& userId, QWidget* parent)
    : BasePage(stack, parent),userID(userId)  {

    QVBoxLayout* mainLayout = new QVBoxLayout(this);
    mainLayout->setContentsMargins(20, 20, 20, 20);

    // 标题栏
    QHBoxLayout* headerLayout = new QHBoxLayout;
    QLabel* title = new QLabel("选择词库", this);
    title->setStyleSheet("font-size: 24px; font-weight: bold; color: #2c3e50;");

    QPushButton* logoutBtn = new QPushButton("退出", this);
    logoutBtn->setStyleSheet("font-size: 14px; color: #e74c3c; background: none; border: none;");
    connect(logoutBtn, &QPushButton::clicked, [this]() {
        // 先切换回登录页，防止当前页删除后访问栈出错
        this->stack->setCurrentIndex(0);

        LoginPage* loginPage = qobject_cast<LoginPage*>(this->stack->widget(0));
        if (loginPage) {
            loginPage->releaseStatsPageForUser(this->userID);
            loginPage->releaseSelectionPageForUser(this->userID);
            loginPage->releaseProgressPageForUser(this->userID);            // 如果有管理选择页也释放
        }
    });

    headerLayout->addWidget(title);
    headerLayout->addStretch();
    headerLayout->addWidget(logoutBtn);

    QListWidget* bookList = new QListWidget(this);
    bookList->setStyleSheet(
        "QListWidget {"
        "  background-color: #20B2AA;"
        "  border-radius: 10px;"
        "  border: 1px solid #dfe6e9;"
        "}"
        "QListWidget::item {"
        "  border-bottom: 1px solid #dfe6e9;"
        "  padding: 15px;"
        "}"
        "QListWidget::item:selected {"
        "  background-color: #40E0D0;"
        "}"
        );

    QStringList books = {
        "大学英语四级核心词汇(1) (120词)",
        "大学英语四级核心词汇(2) (120词)",
        "大学英语四级核心词汇(3) (120词)",
        "大学英语四级核心词汇(4) (120词)",
        "大学英语四级核心词汇(5) (120词)",
        "大学英语六级核心词汇(1) (120词)",
        "大学英语六级核心词汇(2) (120词)",
        "大学英语六级核心词汇(3) (120词)",
        "大学英语六级核心词汇(4) (120词)",
        "大学英语六级核心词汇(5) (120词)",
        "未掌握词汇",
        "已掌握词汇",
    };

    for (const QString& book : books) {
        new QListWidgetItem(book, bookList);
    }

    // 进度显示
    // QProgressBar* progress = new QProgressBar(this);
    // progress->setRange(0, 100);
    // progress->setValue(45);                 //！！！！！！！！！！！！！！！这里给定了45，实际需要统计后台数据##########################
    // progress->setFormat("总体进度: %p%");
    // progress->setStyleSheet(
    //     "QProgressBar {"
    //     "  border: 1px solid #bdc3c7;"
    //     "  border-radius: 5px;"
    //     "  text-align: center;"
    //     "  height: 20px;"
    //     "}"
    //     "QProgressBar::chunk {"
    //     "  background-color: #3498db;"
    //     "  border-radius: 5px;"
    //     "}"
    //     );

    // 按钮区域
    QHBoxLayout* btnLayout = new QHBoxLayout;
    QPushButton* startBtn = new QPushButton("开始学习", this);
    addStyledButton(startBtn, "#3498db");
    connect(startBtn, &QPushButton::clicked, [this, bookList] {
        if (!bookList->currentItem()) {
            QMessageBox::warning(this, "提示", "请先选择词库");
            return;
        }

        QString selectedBook = bookList->currentItem()->text();
        QString fileName;

        // 获取当前登录页指针（一般为 stack 的 index 0）
        LoginPage* loginPage = qobject_cast<LoginPage*>(this->stack->widget(0));
        if (!loginPage) return;

        int userId = loginPage->getUserId();
        ProgressPage* progressPage = loginPage->getProgressPageForUser(userId);

        if (!progressPage) {
            QMessageBox::critical(this, "错误", "学习页面未创建！");
            return;
        }

        if (selectedBook.contains("未掌握词汇")) {
            fileName = QString("%1_unknownWords.json").arg(userID);
            progressPage->loadBook(fileName);
            progressPage->initialCount();
            progressPage->updateProgressLabel();
            progressPage->updateBookTitle("未掌握词汇");
            if (progressPage->isWordListEmpty()) {
                QMessageBox::warning(this, "提示", "还没有未掌握的单词");
                return;
            }
        }
        else if (selectedBook.contains("已掌握词汇")) {
            fileName = QString("%1_knownWords.json").arg(userID);
            progressPage->loadBook(fileName);
            progressPage->initialCount();
            progressPage->updateProgressLabel();
            progressPage->updateBookTitle("已掌握词汇");
            if (progressPage->isWordListEmpty()) {
                QMessageBox::warning(this, "提示", "还没有已掌握的单词");
                return;
            }
        }else if (selectedBook.contains("四级核心词汇")) {
            fileName = "words.json";
            progressPage->loadBook(fileName);
            progressPage->initialCount();
            progressPage->updateProgressLabel();
            progressPage->updateBookTitle("四级核心词汇 120词");
        }
        else if (selectedBook.contains("六级核心词汇")) {
            fileName = "CET6_words.json";
            progressPage->loadBook(fileName);
            progressPage->initialCount();
            progressPage->updateProgressLabel();
            progressPage->updateBookTitle("六级核心词汇 120词");
        }
        this->stack->setCurrentWidget(progressPage);
    });


    QPushButton* statsBtn = new QPushButton("学习统计", this);
    addStyledButton(statsBtn, "#9b59b6");
    connect(statsBtn, &QPushButton::clicked, [this] {
        LoginPage* loginPage = qobject_cast<LoginPage*>(this->stack->widget(0));
        if (!loginPage) return;

        int uid = loginPage->getUserId();

        loginPage->releaseStatsPageForUser(uid);  // 若已存在，释放旧页面
        loginPage->createStatsPageForUser(uid);   // 创建新页面

        StatsPage* statsPage = loginPage->getStatsPageForUser(uid);
        if (statsPage) {
            this->stack->setCurrentWidget(statsPage); // 显式跳转到新页面
        }
    });
    btnLayout->addWidget(statsBtn);
    btnLayout->addStretch();
    btnLayout->addWidget(startBtn);

    // 组合布局
    mainLayout->addLayout(headerLayout);
    mainLayout->addSpacing(20);
    mainLayout->addWidget(bookList);
    mainLayout->addSpacing(10);
    // mainLayout->addWidget(progress);
    mainLayout->addSpacing(20);
    mainLayout->addLayout(btnLayout);


}

SelectionPage::~SelectionPage() {
    releaseStatsPage();  // 确保在页面销毁时释放内存
}

void SelectionPage::releaseStatsPage() {
    if (statsPage) {
        stack->removeWidget(statsPage);
        delete statsPage;
        statsPage = nullptr;

        qDebug() << "统计页面内存已释放";
    }
}
