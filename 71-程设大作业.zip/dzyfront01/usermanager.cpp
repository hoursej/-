#include "usermanager.h"
#include <QSqlError>
#include <QDebug>
#include <QDate>

UserManager::UserManager(QObject *parent)
    : QObject(parent)
{
    // 保证数据库连接唯一，避免多次 addDatabase 导致冲突
    if (QSqlDatabase::contains("user_connection")) {
        db = QSqlDatabase::database("user_connection");
    } else {
        db = QSqlDatabase::addDatabase("QSQLITE", "user_connection");
        db.setDatabaseName("user.db");
    }
}
QSqlDatabase UserManager:: getdb()const
{
    return db;
}

bool UserManager::initDatabase()//打开用户信息文件
{
    if (!db.open()) {
        qDebug() << "Failed to open database:" << db.lastError().text();
        return false;
    }
    qDebug() << "Database opened successfully.";
    return createUserTable();
}

bool UserManager::createUserTable()//创建用户信息表
{
    QSqlQuery query(db);
    QString createTable = R"(
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT,
            password TEXT,
            learn_days INTEGER,
            streak_days INTEGER,
            last_learn_date TEXT,
            words_learned INTEGER,
            total_words INTEGER
        )
    )";
    if (!query.exec(createTable)) {
        qDebug() << "Failed to create users table:" << query.lastError().text();
        return false;
    }
    qDebug() << "User table ready.";
    return true;
}

bool UserManager::addUser(const QString &name, const QString &password, int totalWords)//添加用户
{
    if (!db.isOpen()) return false;

    // 检查是否用户名已存在
    QSqlQuery check(db);
    check.prepare("SELECT COUNT(*) FROM users WHERE name = :name");
    check.bindValue(":name", name);
    if (check.exec() && check.next() && check.value(0).toInt() > 0) {
        qDebug() << "用户名已存在";
        return false;
    }

    QSqlQuery query(db);
    query.prepare(R"(
    INSERT INTO users (name, password, learn_days, streak_days, last_learn_date, words_learned, total_words)
    VALUES (:name, :password, :days, :streak, :lastdate, :learned, :total)
    )");
    query.bindValue(":name", name);
    query.bindValue(":password", password);
    query.bindValue(":days", 0);
    query.bindValue(":streak", 0);
    query.bindValue(":lastdate", "");
    query.bindValue(":learned", 0);//!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!1人为临时设定120数######################
    query.bindValue(":total", totalWords);
    if (!query.exec()) {
        qDebug() << "插入用户失败:" << query.lastError().text();
        return false;
    }
    return true;
}


bool UserManager::incrementLearnDays(int userId)//增加总学习天数，连续学习天数
{
    if (!db.isOpen()) return false;

    // 获取上次学习日期和 streak
    QSqlQuery select(db);
    select.prepare("SELECT last_learn_date, streak_days FROM users WHERE id = :id");
    select.bindValue(":id", userId);

    if (!select.exec() || !select.next()) return false;

    QString lastDateStr = select.value(0).toString();
    int streak = select.value(1).toInt();

    QDate today = QDate::currentDate();
    QDate lastDate = QDate::fromString(lastDateStr, "yyyy-MM-dd");

    // 判断 streak 变化
    if (lastDate == today) {
        qDebug() << "今天已经记录过学习，无需重复更新。";
        return true;
    } else if (lastDate.isValid() && lastDate.daysTo(today) == 1) {
        streak += 1;  // 连续学习
    } else {
        streak = 1;   // 中断或首次学习
    }

    // 更新数据库：learn_days +1，更新 streak、last_date
    QSqlQuery update(db);
    update.prepare(R"(
        UPDATE users
        SET learn_days = learn_days + 1,
            streak_days = :streak,
            last_learn_date = :today
        WHERE id = :id
    )");
    update.bindValue(":streak", streak);
    update.bindValue(":today", today.toString("yyyy-MM-dd"));
    update.bindValue(":id", userId);

    return update.exec();
}
bool UserManager::updateWordsLearned(int userId, int newWords)//增加用户已经学习的单词数
{
    if (!db.isOpen()) return false;

    QSqlQuery query(db);
    query.prepare("UPDATE users SET words_learned = :n WHERE id = :id");
    query.bindValue(":n", newWords);
    query.bindValue(":id", userId);
    return query.exec();
}
QVariantMap UserManager::getUserInfo(int userId)//获取用户信息
{
    QVariantMap result;
    if (!db.isOpen()) return result;

    QSqlQuery query(db);
    query.prepare("SELECT name, learn_days, words_learned, total_words FROM users WHERE id = :id");
    query.bindValue(":id", userId);
    if (query.exec() && query.next()) {
        result["name"] = query.value(0);
        result["learn_days"] = query.value(1);
        result["words_learned"] = query.value(2);
        result["total_words"] = query.value(3);
    }
    return result;
}
