#include "word.h"
#include<QString>
#include <QUrl>
#include <QFileInfo>

Word::Word(const QString& english, const QString& chinese, const QString& pronunciation,const QString& audiopath,
           WordStatus status)
    : m_english(english), m_chinese(chinese), m_pronunciation(pronunciation),
    m_audiofile(audiopath),m_status(status){}

QString Word::english() const { return m_english; }
QString Word::chinese() const { return m_chinese; }
QString Word::pronunciation() const { return m_pronunciation; }
QString Word::audiofile() const{return m_audiofile;}
WordStatus Word::status()const{return m_status;}
QMediaPlayer* Word::player = nullptr;
QAudioOutput* Word::audioOutput = nullptr;

void Word::initPlayer()
{
    if (!player) {
        player = new QMediaPlayer;
        audioOutput = new QAudioOutput;
        player->setAudioOutput(audioOutput);
        audioOutput->setVolume(1.0);
    }
}

void Word::playAudio()
{
    initPlayer();
    if (QFileInfo::exists(m_audiofile)) {
        player->setSource(QUrl::fromLocalFile(m_audiofile));
        player->play();
        qDebug()<<"音频已播放";
    } else {
        qWarning() << "音频文件不存在:" << m_audiofile;
    }
}
