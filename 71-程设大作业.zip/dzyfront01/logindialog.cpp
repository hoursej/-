#include "logindialog.h"
#include "ui_logindialog.h"
#include<QMessageBox>
#include "usermanager.h"

LoginDialog::LoginDialog(QWidget *parent)
    : QDialog(parent)
    , ui(new Ui::LoginDialog)
{
    ui->setupUi(this);
}

LoginDialog::~LoginDialog()
{
    delete ui;
}

int LoginDialog::getUserId()const
{
    return userId;
}

void LoginDialog::on_loginButton_clicked()
{
    QString username = ui->usernameEdit->text().trimmed();
    QString password = ui->passwordEdit->text();

    if (username.isEmpty() || password.isEmpty()) {
        QMessageBox::warning(this, "错误", "请输入账号和密码！");
        return;
    }

    UserManager manager;
    manager.initDatabase();

    QSqlQuery query(manager.getdb());
    query.prepare("SELECT id FROM users WHERE name = :name AND password = :password");
    query.bindValue(":name", username);
    query.bindValue(":password", password);

    if (query.exec() && query.next()) {
        userId = query.value(0).toInt(); // 登录成功，保存 ID
        accept(); // 关闭登录窗口
    } else {
        QMessageBox::warning(this, "登录失败", "用户名或密码错误！");
    }
}

void LoginDialog::on_pushButton_clicked()
{
    QString username = ui->usernameEdit->text().trimmed();
    QString password = ui->passwordEdit->text();

    if (username.isEmpty() || password.isEmpty()) {
        QMessageBox::warning(this, "错误", "请输入账号和密码！");
        return;
    }

    UserManager manager;
    if (!manager.initDatabase()) {
        QMessageBox::critical(this, "错误", "数据库初始化失败！");
        return;
    }

    // 先检测用户名是否存在
    QSqlQuery checkQuery(manager.getdb());
    checkQuery.prepare("SELECT COUNT(*) FROM users WHERE name = :name");
    checkQuery.bindValue(":name", username);
    if (checkQuery.exec() && checkQuery.next()) {
        if (checkQuery.value(0).toInt() > 0) {
            QMessageBox::warning(this, "提示", "用户名已存在，请换一个！");
            return;
        }
    }

    // 添加用户（注册）
    if (!manager.addUser(username, password, 10)) {
        QMessageBox::critical(this, "注册失败", "数据库写入失败！");
        return;
    }

    qDebug() << "注册成功";

    // 注册成功后直接登录
    QSqlQuery query(manager.getdb());
    query.prepare("SELECT id FROM users WHERE name = :name AND password = :password");
    query.bindValue(":name", username);
    query.bindValue(":password", password);

    if (query.exec() && query.next()) {
        userId = query.value(0).toInt();
        accept(); // 登录成功，关闭窗口
    } else {
        QMessageBox::warning(this, "登录失败", "注册成功但登录失败！");
    }
}


