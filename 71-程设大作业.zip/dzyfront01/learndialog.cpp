#include "learndialog.h"
#include "ui_learndialog.h"
#include "wordmanager.h"
#include<QTimer>
#include<QMessageBox>
#include <QtConcurrent>

LearnDialog::LearnDialog(QWidget *parent)
    : QDialog(parent)
    , ui(new Ui::LearnDialog),wordIndex(0)
{
    ui->setupUi(this);
}

void LearnDialog::showEvent(QShowEvent *event) {
    QDialog::showEvent(event);
    QTimer::singleShot(0, this, &LearnDialog::loadData);
}

void LearnDialog::loadData() {
    // 异步加载数据
   QThreadPool::globalInstance()->start([this]() {
        QList<Word> loadedWords = WordManager::loadFromJSON("words.json");
        QMetaObject::invokeMethod(this, [this, loadedWords]() {
            Word::initPlayer();
            words = loadedWords;
            if (words.isEmpty()) {
                qWarning() << "加载失败或文件为空！";
            } else {
                qDebug() << "成功加载" << words.size() << "个单词。";
            }
            showLabelText();
        }, Qt::QueuedConnection);
    });
}


LearnDialog::~LearnDialog()
{
    delete ui;
}

void LearnDialog::showLabelText()
{
    ui->english_label->setText(words[wordIndex].english());
    ui->chinese_label->setText(words[wordIndex].chinese());
    ui->yinbiao_label->setText(words[wordIndex].pronunciation());
}

void LearnDialog::on_pronunce_button_clicked()
{
    words[wordIndex].playAudio();
}

void LearnDialog::on_last_button_clicked()
{
    if(wordIndex==0)
        QMessageBox::information(this, "提示", "已经是第一个了");
    else
    {
        wordIndex--;
        showLabelText();
    }
}

void LearnDialog::on_next_button_clicked()
{
    if(wordIndex==words.size()-1)
        QMessageBox::information(this,"提示","已经是最后一个了");
    else
    {
        wordIndex++;
        showLabelText();
    }
}

