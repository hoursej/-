#include "learndialog.h"
#include "loginp.h"
#include "mainwindow.h"
#include "qboxlayout.h"
#include "progressp.h"
#include <QApplication>
#include <QStackedWidget>
#include <QStyleFactory>
#include <QPalette>

int main(int argc, char *argv[])
{
    QApplication app(argc, argv);

    QApplication::setStyle(QStyleFactory::create("Fusion"));
    QPalette palette;
    palette.setColor(QPalette::Window, QColor(240, 240, 240));
    palette.setColor(QPalette::WindowText, QColor(45, 45, 45));
    app.setPalette(palette);

    QWidget mainWindow;
    mainWindow.setWindowTitle("超级英语单词英雄");
    mainWindow.resize(900, 700);

    QStackedWidget* stack = new QStackedWidget(&mainWindow);
    stack->addWidget(new LoginPage(stack));

    QVBoxLayout* layout = new QVBoxLayout(&mainWindow);
    layout->addWidget(stack);
    layout->setContentsMargins(0, 0, 0, 0);

    mainWindow.show();
    return app.exec();
}
