#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QString>
#include <QPushButton>
#include <QDebug>
#include "basep.h"
#include "player.h"
#include"monster.h"
#include <QObject>
using namespace std;
QT_BEGIN_NAMESPACE
namespace Ui {
class MainWindow;
}
QT_END_NAMESPACE

class MainWindow : public BasePage
{
    Q_OBJECT



public:
    MainWindow(QStackedWidget* stack, QWidget* parent);
    ~MainWindow();
    void setQLab_name(QString Lab_name);//设置题目（Q)
    void setABtn_name(QString Btn_name);//设置选项（通过更改Btn文本）
    void setBBtn_name(QString Btn_name);
    void setCBtn_name(QString Btn_name);
    void setDBtn_name(QString Btn_name);
    Monster monster;
    Player Me;

signals:
    void sig_mdamage(int amount);
    void sig_edamage(int amount);

private slots:
    void on_ABtn_clicked();

    void on_BBtn_clicked();

    void on_CBtn_clicked();

    void on_DBtn_clicked();



private:
    void setButtonColor(QPushButton *btn,const QString &color);
    Ui::MainWindow *ui;
};
#endif // MAINWINDOW_H
