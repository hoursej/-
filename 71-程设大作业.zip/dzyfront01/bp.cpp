#include "bp.h"
#include "ui_bp.h"

bp::bp(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::bp)
{
    ui->setupUi(this);
}

bp::~bp()
{
    delete ui;
}
