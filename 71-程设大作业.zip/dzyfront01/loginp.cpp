#include "loginp.h"
#include "statsp.h"
#include "progressp.h"
#include "usermanager.h"
#include "selectp.h"
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QLabel>
#include <QPushButton>
#include <QMessageBox>
#include <QColor>

LoginPage::LoginPage(QStackedWidget* stack, QWidget* parent)
    : BasePage(stack, parent) {

    QVBoxLayout* layout = new QVBoxLayout(this);
    layout->setSpacing(20);
    layout->setContentsMargins(50, 50, 50, 50);

    QLabel* title = new QLabel("超级英语单词英雄", this);
    title->setStyleSheet("font-size: 32px; font-weight: bold; color: #2c3e50;");
    title->setAlignment(Qt::AlignCenter);

    QLabel* subtitle = new QLabel("某小组的大作业", this);
    subtitle->setStyleSheet("font-size: 18px; color: #7f8c8d;");
    subtitle->setAlignment(Qt::AlignCenter);

    usernameEdit = new QLineEdit(this);
    usernameEdit->setPlaceholderText("用户名");
    styleLineEdit(usernameEdit);

    passwordEdit = new QLineEdit(this);
    passwordEdit->setPlaceholderText("密码");
    passwordEdit->setEchoMode(QLineEdit::Password);
    styleLineEdit(passwordEdit);

    QPushButton* loginBtn = new QPushButton("登录", this);
    addStyledButton(loginBtn, "#3498db");
    connect(loginBtn, &QPushButton::clicked, this, &LoginPage::attemptLogin);

    QPushButton* registerBtn = new QPushButton("注册并登录", this);
    addStyledButton(registerBtn, "#2ecc71");
    connect(registerBtn, &QPushButton::clicked, this, &LoginPage::showRegister);

    layout->addStretch(1);
    layout->addWidget(title);
    layout->addWidget(subtitle);
    layout->addSpacing(40);
    layout->addWidget(usernameEdit);
    layout->addWidget(passwordEdit);
    layout->addSpacing(20);
    layout->addWidget(loginBtn);
    layout->addWidget(registerBtn);
    layout->addStretch(1);
}

void LoginPage::styleLineEdit(QLineEdit* edit) {
    edit->setStyleSheet(
        "QLineEdit {"
        "  padding: 12px;"
        "  font-size: 16px;"
        "  border: 2px solid #bdc3c7;"
        "  border-radius: 8px;"
        "}"
        "QLineEdit:focus {"
        "  border: 2px solid #3498db;"
        "}"
        );
    edit->setMinimumHeight(50);
}

int LoginPage::getUserId() const {
    return userId;
}

void LoginPage::attemptLogin() {
    QString username = usernameEdit->text().trimmed();
    QString password = passwordEdit->text();

    if (username.isEmpty() || password.isEmpty()) {
        QMessageBox::warning(this, "错误", "请输入账号和密码！");
        return;
    }

    UserManager manager;
    manager.initDatabase();

    QSqlQuery query(manager.getdb());
    query.prepare("SELECT id FROM users WHERE name = :name AND password = :password");
    query.bindValue(":name", username);
    query.bindValue(":password", password);

    if (query.exec() && query.next()) {
        userId = query.value(0).toInt();

        SelectionPage* selectionPage = new SelectionPage(stack, userId);
        stack->addWidget(selectionPage);

        createStatsPageForUser(userId);
        qDebug() << "准备创建学习页面";
        createProgressPageForUser(userId);
        qDebug() << "createProgressPageForUser 调用完毕";
        createSelectionPageForUser(userId);

        userStatsPages[userId]->um->incrementLearnDays(userId);

        stack->setCurrentWidget(selectionPage);
    } else {
        QMessageBox::warning(this, "登录失败", "用户名或密码错误！");
    }
}

void LoginPage::showRegister() {
    QString username = usernameEdit->text().trimmed();
    QString password = passwordEdit->text();

    if (username.isEmpty() || password.isEmpty()) {
        QMessageBox::warning(this, "错误", "请输入账号和密码！");
        return;
    }

    UserManager manager;
    if (!manager.initDatabase()) {
        QMessageBox::critical(this, "错误", "数据库初始化失败！");
        return;
    }

    QSqlQuery checkQuery(manager.getdb());
    checkQuery.prepare("SELECT COUNT(*) FROM users WHERE name = :name");
    checkQuery.bindValue(":name", username);
    if (checkQuery.exec() && checkQuery.next() && checkQuery.value(0).toInt() > 0) {
        QMessageBox::warning(this, "提示", "用户名已存在，请换一个！");
        return;
    }

    if (!manager.addUser(username, password, 10)) {
        QMessageBox::critical(this, "注册失败", "数据库写入失败！");
        return;
    }

    QSqlQuery query(manager.getdb());
    query.prepare("SELECT id FROM users WHERE name = :name AND password = :password");
    query.bindValue(":name", username);
    query.bindValue(":password", password);

    if (query.exec() && query.next()) {
        userId = query.value(0).toInt();

        SelectionPage* selectionPage = new SelectionPage(stack, userId);
        stack->addWidget(selectionPage);

        createStatsPageForUser(userId);
        createProgressPageForUser(userId);
        createSelectionPageForUser(userId);

        userStatsPages[userId]->um->incrementLearnDays(userId);

        stack->setCurrentWidget(selectionPage);
    } else {
        QMessageBox::warning(this, "登录失败", "注册成功但登录失败！");
    }
}

void LoginPage::createStatsPageForUser(const int& userId) {
    if (userStatsPages.contains(userId)) {
        releaseStatsPageForUser(userId);
    }

    StatsPage* statsPage = new StatsPage(stack, userId);
    stack->addWidget(statsPage);
    userStatsPages[userId] = statsPage;

    qDebug() << "为用户" << userId << "创建统计页面";
}

void LoginPage::createProgressPageForUser(const int& userId) {
    if (userProgressPages.contains(userId)) {
        releaseProgressPageForUser(userId);
    }

    ProgressPage* progressPage = new ProgressPage(stack,userId);
    stack->addWidget(progressPage);
    userProgressPages[userId] = progressPage;

    qDebug() << "为用户" << userId << "创建学习页面";
}

void LoginPage::releaseStatsPageForUser(const int& userId) {
    if (userStatsPages.contains(userId)) {
        StatsPage* statsPage = userStatsPages.value(userId);
        stack->removeWidget(statsPage);
        delete statsPage;
        userStatsPages.remove(userId);
        qDebug() << "已释放用户" << userId << "的统计页面内存";
    }
}

void LoginPage::releaseProgressPageForUser(const int& userId) {
    if (userProgressPages.contains(userId)) {
        ProgressPage* progressPage = userProgressPages.value(userId);
        stack->removeWidget(progressPage);
        delete progressPage;
        userProgressPages.remove(userId);
        qDebug() << "已释放用户" << userId << "的学习页面内存";
    }
}

void LoginPage::createSelectionPageForUser(int userId) {
    if (userSelectionPages.contains(userId)) {
        releaseSelectionPageForUser(userId);
    }
    SelectionPage* page = new SelectionPage(stack, userId);
    userSelectionPages[userId] = page;
    stack->addWidget(page);
}

void LoginPage::releaseSelectionPageForUser(int userId) {
    if (userSelectionPages.contains(userId)) {
        SelectionPage* page = userSelectionPages.value(userId);
        stack->removeWidget(page);
        delete page;
        userSelectionPages.remove(userId);
        qDebug() << "已释放用户" << userId << "的选择页面内存";
    }
}

ProgressPage* LoginPage::getProgressPageForUser(int userId) const {
    return userProgressPages.contains(userId) ? userProgressPages.value(userId) : nullptr;
}

StatsPage* LoginPage::getStatsPageForUser(int userId) const {
    return userStatsPages.value(userId, nullptr);
}

SelectionPage* LoginPage::getSelectionPageForUser(int userId) const {
    return userSelectionPages.value(userId, nullptr);
}
