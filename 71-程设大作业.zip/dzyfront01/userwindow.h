#ifndef USERWINDOW_H
#define USERWINDOW_H

#include <QDialog>
#include "qstackedwidget.h"
#include "usermanager.h"

namespace Ui {
class UserWindow;
}

class UserWindow : public QDialog
{
    Q_OBJECT

public:
    explicit UserWindow(QStackedWidget* stack,int userId,QWidget *parent = nullptr);
    ~UserWindow();
    UserManager *um;
private:
    Ui::UserWindow *ui;
//    UserManager *um;
};

#endif // USERWINDOW_H
