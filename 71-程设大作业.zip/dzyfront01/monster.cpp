#include "monster.h"
#include <QDebug>
Monster::Monster()
{
    e_Hp=50;
    e_AttackPower=10;
}
int Monster::getHp()
{
    return e_Hp;
}
int Monster::getAttackPower()
{
    return e_AttackPower;
}
void Monster::injured(int a)/////
{
    e_Hp-=a;
}

//connect(mainwindow,&MainWindow::damageTaken,monster,&Monster::injured);
