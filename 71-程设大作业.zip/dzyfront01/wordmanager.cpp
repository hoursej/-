#include "wordmanager.h"
#include<QVector>
#include <QFile>
#include <QJsonDocument>
#include <QJsonArray>
#include <QJsonObject>
#include <QDebug>

WordManager::WordManager() {}
QVector<Word> WordManager::loadFromJSON(const QString& path)//从文件读取单词
{
    QVector<Word> words;
    QFile file(path);
    if (!file.open(QIODevice::ReadOnly))
    {
        qDebug()<<"Not found file"<<Qt::endl;
        return words;
    }
    QByteArray data = file.readAll();
    file.close();

    QJsonDocument doc = QJsonDocument::fromJson(data);
    if (!doc.isArray())
    {
        qDebug()<<"Not JSON array"<<Qt::endl;
        return words;
    }
    QJsonArray array = doc.array();
    for (int i = 0; i < array.size(); ++i) {
        QJsonObject obj = array.at(i).toObject();
        Word word(
            obj["english"].toString(),
            obj["chinese"].toString(),
            obj["pronunciation"].toString(),
            obj["audio"].toString(),
            obj["status"].toString() == "Killed" ? Killed : NotKilled
            );
        words.append(word);
    }
    return words;
}
void WordManager::saveWordToJSON(const Word& word, const QString& filePath)
{
    // 1. 尝试读取已有文件内容
    QFile file(filePath);
    QJsonArray array;

    if (file.exists() && file.open(QIODevice::ReadOnly)) {
        QJsonDocument doc = QJsonDocument::fromJson(file.readAll());
        array = doc.array();
        file.close();

        // 2. 检查是否已有相同的单词（以 english 字段为主键）
        for (const QJsonValue& val : array) {
            QJsonObject obj = val.toObject();
            if (obj["english"].toString() == word.english()) {
                qDebug() << "Word already exists in file, not adding:" << word.english();
                return;
            }
        }
    }

    // 3. 构造新的单词对象
    QJsonObject obj;
    obj["english"] = word.english();
    obj["chinese"] = word.chinese();
    obj["pronunciation"] = word.pronunciation();
    obj["audio"] = word.audiofile();
    obj["status"] = word.status() == Killed ? "Killed" : "NotKilled";

    // 4. 添加并保存
    array.append(obj);

    QJsonDocument newDoc(array);
    if (file.open(QIODevice::WriteOnly | QIODevice::Truncate)) {
        file.write(newDoc.toJson());
        file.close();
        qDebug() << "Word saved successfully:" << word.english();
    } else {
        qWarning() << "Failed to open file for writing:" << file.errorString();
    }
}

void WordManager::removeWordFromJSON(const Word& word, const QString& filePath)
{
    QFile file(filePath);
    if (!file.exists()) {
        qWarning() << "File does not exist:" << filePath;
        return;
    }

    if (!file.open(QIODevice::ReadOnly)) {
        qWarning() << "Failed to open file for reading:" << file.errorString();
        return;
    }

    // 读取 JSON 文档
    QJsonDocument doc = QJsonDocument::fromJson(file.readAll());
    file.close();

    if (!doc.isArray()) {
        qWarning() << "Invalid JSON format: expected array.";
        return;
    }

    QJsonArray array = doc.array();
    QJsonArray newArray;

    // 遍历 JSON 数组，保留不是要删除的那个单词
    for (const QJsonValue& val : array) {
        QJsonObject obj = val.toObject();
        if (obj["english"].toString() != word.english()) {
            newArray.append(obj);
        } else {
            qDebug() << "Deleted word:" << word.english();
        }
    }

    // 写回修改后的 JSON
    if (file.open(QIODevice::WriteOnly | QIODevice::Truncate)) {
        QJsonDocument newDoc(newArray);
        file.write(newDoc.toJson());
        file.close();
    } else {
        qWarning() << "Failed to open file for writing:" << file.errorString();
    }
}
