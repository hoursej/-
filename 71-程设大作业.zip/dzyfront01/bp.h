#ifndef BP_H
#define BP_H

#include <QWidget>

QT_BEGIN_NAMESPACE
namespace Ui {
class bp;
}
QT_END_NAMESPACE

class bp : public QWidget
{
    Q_OBJECT

public:
    bp(QWidget *parent = nullptr);
    ~bp();

private:
    Ui::bp *ui;
};
#endif // BP_H
