#ifndef WORDMANAGER_H
#define WORDMANAGER_H
#include"word.h"

class WordManager
{
public:
    WordManager();
    static QVector<Word>loadFromJSON(const QString& path);
    static void saveWordToJSON(const Word& word,const QString& path);
    static void removeWordFromJSON(const Word& word, const QString& filePath);

};

#endif // WORDMANAGER_H
