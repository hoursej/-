#include "statsp.h"
#include "usermanager.h"
#include "loginp.h"
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QLabel>
#include <QPushButton>
#include <QFrame>
#include <QMessageBox>

StatsPage::StatsPage(QStackedWidget* stack,int userId, QWidget* parent)
    : BasePage(stack, parent), userId(userId)  {
    um = new UserManager(this);
    if (!um->initDatabase()) {
        qDebug() << "Database initialization failed!";
    }
    QVariantMap userInfo = um->getUserInfo(userId);
    if (userInfo.isEmpty()) {
        QMessageBox::warning(this, "查询失败", "未找到该用户！");
        return;
    }

    QVBoxLayout* mainLayout = new QVBoxLayout(this);
    mainLayout->setContentsMargins(40, 30, 40, 30);

    // 标题栏
    QHBoxLayout* headerLayout = new QHBoxLayout;
    QLabel* title = new QLabel("学习统计", this);
    title->setStyleSheet("font-size: 24px; font-weight: bold; color: #2c3e50;");

    QPushButton* backBtn = new QPushButton("返回", this);
    addStyledButton(backBtn, "#95a5a6");
    connect(backBtn, &QPushButton::clicked, [this] {
        LoginPage* loginPage = qobject_cast<LoginPage*>(this->stack->widget(0));
        if (!loginPage) return;

        int uid = loginPage->getUserId();

        SelectionPage* selectionPage = loginPage->getSelectionPageForUser(uid);
        if (selectionPage) {
            this->stack->setCurrentWidget(selectionPage); // 显式切换
        }
    });

    headerLayout->addWidget(title);
    headerLayout->addStretch();
    headerLayout->addWidget(backBtn);

    QWidget* cardsContainer = new QWidget(this);
    QHBoxLayout* cardsLayout = new QHBoxLayout(cardsContainer);
    cardsLayout->setSpacing(20);

    createStatCard(cardsLayout, "#3498db", "用户: ", userInfo["name"].toString(),"");
    //createStatCard(cardsLayout, "#2ecc71", "连续学习天数: ", userInfo["streak_days"].toString(), "");
    createStatCard(cardsLayout, "#2ecc71", "总学习天数: ", userInfo["learn_days"].toString(), "");
    createStatCard(cardsLayout, "#9b59b6", "已学单词数: ", userInfo["words_learned"].toString(), "坚持就是胜利");



    // 组合布局
    mainLayout->addLayout(headerLayout);
    mainLayout->addSpacing(20);
    mainLayout->addWidget(cardsContainer);
    mainLayout->addSpacing(20);

}

void StatsPage::createStatCard(QLayout* layout, const QString& color,
                               const QString& title, const QString& value,
                               const QString& description) {

    QWidget* card = new QWidget;
    card->setStyleSheet(
        "QWidget {"
        "  background-color: white;"
        "  border-radius: 15px;"
        "  border: 1px solid #dfe6e9;"
        "}"
        );

    QVBoxLayout* cardLayout = new QVBoxLayout(card);
    cardLayout->setContentsMargins(20, 20, 20, 20);
    cardLayout->setSpacing(10);

    QLabel* titleLabel = new QLabel(title, card);
    titleLabel->setStyleSheet(QString(
                                  "font-size: 16px;"
                                  "color: %1;"
                                  "font-weight: bold;"
                                  ).arg(color));

    QLabel* valueLabel = new QLabel(value, card);
    valueLabel->setStyleSheet(
        "font-size: 28px;"
        "font-weight: bold;"
        "color: #2c3e50;"
        );
    valueLabel->setAlignment(Qt::AlignCenter);

    QLabel* descLabel = new QLabel(description, card);
    descLabel->setStyleSheet(
        "font-size: 14px;"
        "color: #7f8c8d;"
        );
    descLabel->setAlignment(Qt::AlignCenter);

    cardLayout->addWidget(titleLabel);
    cardLayout->addWidget(valueLabel, 1);
    cardLayout->addWidget(descLabel);

    layout->addWidget(card);
}
