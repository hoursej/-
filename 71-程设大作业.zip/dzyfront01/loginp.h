#ifndef LOGINP_H
#define LOGINP_H

#include "basep.h"
#include "statsp.h"
#include "selectp.h"
#include "progressp.h"
#include <QWidget>
#include <QDialog>

class LoginPage : public BasePage {
    Q_OBJECT
public:
    explicit LoginPage(QStackedWidget* stack, QWidget* parent = nullptr);
    int getUserId()const;
    void createStatsPageForUser(const int& userId);
    void releaseStatsPageForUser(const int& userId);
    void createProgressPageForUser(const int& userId);
    void releaseProgressPageForUser(const int& userId);
    void createSelectionPageForUser(int userId);
    void releaseSelectionPageForUser(int userId);
    ProgressPage* getProgressPageForUser(int userId) const;
    StatsPage* getStatsPageForUser(int userId) const;
    SelectionPage* getSelectionPageForUser(int userId) const;

private:
    QLineEdit* usernameEdit;
    QLineEdit* passwordEdit;

    QMap<int, StatsPage*> userStatsPages;
    QMap<int, ProgressPage*> userProgressPages;
    QMap<int, SelectionPage*> userSelectionPages;
    void styleLineEdit(QLineEdit* edit);
    void attemptLogin();
    void showRegister();
    int userId;
signals:
};

#endif // LOGINP_H
