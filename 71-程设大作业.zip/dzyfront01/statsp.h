#ifndef STATSP_H
#define STATSP_H

#include "basep.h"
#include "usermanager.h"

class StatsPage : public BasePage {
    Q_OBJECT
public:
    explicit StatsPage(QStackedWidget* stack,int userId, QWidget* parent = nullptr);
    UserManager *um;

    int getUserId() const { return userId; }

private:
    int userId;
    void createStatCard(QLayout* layout, const QString& color,
                        const QString& title, const QString& value,
                        const QString& description);
signals:
};

#endif // STATSP_H
