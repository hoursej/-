#include "player.h"
#include <QDebug>
Player::Player()
{
    m_Hp=100;
    m_weapon=sword;
    m_AttackPower=15;
}



int Player::getAttackPower()
{
    return m_AttackPower;
}

int Player::getHp()
{
    return m_Hp;
}

