#include "progressp.h"
#include "word.h"
#include "wordmanager.h"
#include "loginp.h"
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QLabel>
#include <QPushButton>
#include <QMessageBox>
#include <QFrame>

ProgressPage::ProgressPage(QStackedWidget* stack, int userId,QWidget* parent)
    : BasePage(stack, parent),userID(userId),count(0) {
    // um = new UserManager(this);
    // if (!um->initDatabase()) {
    //     qDebug() << "Database initialization failed!";
    // }
    // QVariantMap userInfo = um->getUserInfo(userId);
    QVBoxLayout* mainLayout = new QVBoxLayout(this);
    mainLayout->setContentsMargins(40, 30, 40, 30);

    QHBoxLayout* infoLayout = new QHBoxLayout;

    bookTitle = new QLabel("", this);
    bookTitle->setStyleSheet("font-size: 18px; font-weight: bold; color: #2c3e50;");

    knownWords = WordManager::loadFromJSON(QString("%1_knownWords.json").arg(userID));
    progressLabel = new QLabel("0/0", this);
    progressLabel->setStyleSheet("font-size: 16px; color: #7f8c8d;");

    infoLayout->addWidget(bookTitle);
    infoLayout->addStretch();
    infoLayout->addWidget(progressLabel);
    //words = WordManager::loadFromJSON("words.json");
    // 单词显示区
    QFrame* wordFrame = new QFrame(this);
    wordFrame->setStyleSheet(
        "QFrame {"
        "  background-color: white;"
        "  border-radius: 15px;"
        "  border: 1px solid #dfe6e9;"
        "}"
        );

    QVBoxLayout* wordLayout = new QVBoxLayout(wordFrame);
    wordLayout->setContentsMargins(40, 40, 40, 40);

    currentWord = new QLabel("", this);
    currentWord->setStyleSheet("font-size: 48px; font-weight: bold; color: #2c3e50; text-align: center;");

    phonetic = new QLabel("", this);
    phonetic->setStyleSheet("font-size: 24px; color: #7f8c8d; text-align: center;");

    meaning = new QLabel("", this);
    meaning->setStyleSheet("font-size: 28px; color: #2c3e50; text-align: center; margin-top: 30px;");
    meaning->hide();

    wordLayout->addWidget(currentWord);
    wordLayout->addWidget(phonetic);
    wordLayout->addWidget(meaning);

    // 按钮区域
    QHBoxLayout* btnLayout = new QHBoxLayout;
    QPushButton* lastBtn = new QPushButton("上一个", this);
    addStyledButton(lastBtn, "#FF1493");
    connect(lastBtn, &QPushButton::clicked, [this] {
        loadLastWord();
        updateProgressLabel();
    });

    QPushButton* nextBtn = new QPushButton("下一个", this);
    addStyledButton(nextBtn, "#FF1493");
    connect(nextBtn, &QPushButton::clicked, [this] {
        loadNextWord();
        updateProgressLabel();
    });

    QPushButton* audioBtn = new QPushButton("发音", this);
    addStyledButton(audioBtn, "#3498db");
    connect(audioBtn, &QPushButton::clicked, [this] {
        words[count].initPlayer();
        words[count].playAudio();
    });
    QPushButton* showBtn = new QPushButton("显示释义", this);
    addStyledButton(showBtn, "#3498db");
    connect(showBtn, &QPushButton::clicked, [this] {
        meaning->show();
    });

    QPushButton* hideBtn = new QPushButton("隐藏释义", this);
    addStyledButton(hideBtn, "#3498db");
    connect(hideBtn, &QPushButton::clicked, [this] {
        meaning->hide();
    });

    QPushButton* knownBtn = new QPushButton("认识", this);
    addStyledButton(knownBtn, "#2ecc71");
    connect(knownBtn, &QPushButton::clicked, [this] {
        QMessageBox::information(this, "提示", "已标记为已掌握");
        Word current(
            currentWord->text(),
            meaning->text(),
            phonetic->text(),
            "audio/" + currentWord->text() + ".mp3",
            WordStatus::NotKilled  // 默认状态
            );
        WordManager::removeWordFromJSON(current,QString("%1_unknownWords.json").arg(userID));
        WordManager::saveWordToJSON(current,QString("%1_knownWords.json").arg(userID));
        knownWords = WordManager::loadFromJSON(QString("%1_knownWords.json").arg(userID));
    });

    QPushButton* unknownBtn = new QPushButton("不认识", this);
    addStyledButton(unknownBtn, "#e74c3c");
    connect(unknownBtn, &QPushButton::clicked, [this] {
        QMessageBox::information(this, "提示", "已加入复习列表");
        Word current(
            currentWord->text(),
            meaning->text(),
            phonetic->text(),
            "audio/" + currentWord->text() + ".mp3",
            WordStatus::NotKilled  // 默认状态
            );
        WordManager::removeWordFromJSON(current,QString("%1_knownWords.json").arg(userID));
        WordManager::saveWordToJSON(current,QString("%1_unknownWords.json").arg(userID));
        knownWords = WordManager::loadFromJSON(QString("%1_knownWords.json").arg(userID));
        //loadNextWord();
    });

    QPushButton* backBtn = new QPushButton("返回", this);
    addStyledButton(backBtn, "#95a5a6");
    connect(backBtn, &QPushButton::clicked, [this] {
        LoginPage* loginPage = qobject_cast<LoginPage*>(this->stack->widget(0));
        if (!loginPage) return;

        int uid = loginPage->getUserId();
        int delta = knownWords.size();
        if (delta > 0) {
            UserManager manager;
            if (manager.initDatabase()) {
                manager.updateWordsLearned(uid, delta);
            }
        }
        SelectionPage* selectionPage = loginPage->getSelectionPageForUser(uid);
        if (selectionPage) {
            this->stack->setCurrentWidget(selectionPage);
        }
    });


    btnLayout->addWidget(backBtn);
    btnLayout->addStretch();
    btnLayout->addWidget(lastBtn);
    btnLayout->addWidget(nextBtn);
    btnLayout->addWidget(audioBtn);
    btnLayout->addWidget(showBtn);
    btnLayout->addWidget(hideBtn);
    btnLayout->addWidget(unknownBtn);
    btnLayout->addWidget(knownBtn);

    // 组合布局
    mainLayout->addLayout(infoLayout);
    mainLayout->addSpacing(20);
    mainLayout->addWidget(wordFrame, 1);
    mainLayout->addSpacing(20);
    mainLayout->addLayout(btnLayout);

}

void ProgressPage::loadBook(const QString& fileName) {
    words = WordManager::loadFromJSON(fileName);

    if (words.isEmpty()) {
        QMessageBox::warning(this, "提示", "该词库为空或加载失败！");
    }
    else
    {
        currentWord->setText(words[0].english());
        phonetic->setText(words[0].pronunciation());
        meaning->setText(words[0].chinese());
    }
}

void ProgressPage::loadNextWord() {         //！！！！！！！！！！！！！！！！！！！！！！！！这里需要词库#######################
    count++;
    if (count >= words.size()) count = 0;

    currentWord->setText(words[count].english());
    phonetic->setText(words[count].pronunciation());
    meaning->setText(words[count].chinese());

    meaning->hide();

}
void ProgressPage::loadLastWord(){
    count--;
    if (count <= -1) count = words.size()-1;

    currentWord->setText(words[count].english());
    phonetic->setText(words[count].pronunciation());
    meaning->setText(words[count].chinese());
    meaning->hide();

}
bool ProgressPage::isWordListEmpty() const {
    return words.isEmpty();
}

void ProgressPage::updateProgressLabel() {
    progressLabel->setText(QString("进度: %1/%2").arg(count + 1).arg(words.size()));
}
void ProgressPage::updateBookTitle(const QString& name) {
    bookTitle->setText(name);
}

void ProgressPage::initialCount()
{
    count = 0;
}
