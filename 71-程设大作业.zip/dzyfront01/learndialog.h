#ifndef LEARNDIALOG_H
#define LEARNDIALOG_H

#include <QDialog>
#include "word.h"

namespace Ui {
class LearnDialog;
}

class LearnDialog : public QDialog
{
    Q_OBJECT

public:
    explicit LearnDialog(QWidget *parent = nullptr);
    ~LearnDialog();
    void showLabelText();

protected:
    void showEvent(QShowEvent *event) override;

private slots:
    void on_pronunce_button_clicked();

    void on_last_button_clicked();

    void on_next_button_clicked();

private:
    Ui::LearnDialog *ui;
    QVector<Word>words;
    int wordIndex;
    void loadData();
};

#endif // LEARNDIALOG_H
