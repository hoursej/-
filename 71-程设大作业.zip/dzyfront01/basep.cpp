#include "basep.h"
#include <QPushButton>
#include <QColor>
#include <QVBoxLayout>
#include <QHBoxLayout>

BasePage::BasePage(QStackedWidget* stack, QWidget* parent)
    : QWidget(parent), stack(stack)
{
    this->setStyleSheet(
        "QWidget { background-color: #87CEEB; }"
        "QLabel, QLineEdit, QPushButton {"
        "   background-color: transparent;"
        "}"
        );
    this->setAttribute(Qt::WA_StyledBackground, true);
}

void BasePage::addStyledButton(QPushButton* btn, const QString& color) {
    QColor baseColor(color);
    QColor hoverColor = baseColor.darker(120);

    btn->setStyleSheet(QString(
                           "QPushButton {"
                           "  background-color: %1;"
                           "  color: white;"
                           "  border-radius: 15px;"
                           "  padding: 10px 20px;"
                           "  font-size: 16px;"
                           "  font-weight: bold;"
                           "}"
                           "QPushButton:hover {"
                           "  background-color: %2;"
                           "}"
                           "QPushButton:pressed {"
                           "  background-color: %3;"
                           "}"
                           ).arg(color, hoverColor.name(), baseColor.darker(150).name()));
}
