#ifndef SELECTP_H
#define SELECTP_H

#include "basep.h"
#include "statsp.h"
#include <QListWidget>

class SelectionPage : public BasePage {
    Q_OBJECT
public:
    explicit SelectionPage(QStackedWidget* stack,const int& userId, QWidget* parent = nullptr);
    ~SelectionPage();
    int getUserId() const { return userID; }
private:
    StatsPage* statsPage = nullptr;
    void releaseStatsPage();
    int userID;
signals:
};

#endif // SELECTP_H
