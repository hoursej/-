#include "userwindow.h"
#include "ui_userwindow.h"
#include <QMessageBox>

UserWindow::UserWindow(QStackedWidget* stack,int userId,QWidget *parent)
    : QDialog(parent)
    , ui(new Ui::UserWindow)
{
    ui->setupUi(this);
    um = new UserManager(this);
    if (!um->initDatabase()) {
        qDebug() << "Database initialization failed!";
    }
    QVariantMap userInfo = um->getUserInfo(userId);
    if (userInfo.isEmpty()) {
        QMessageBox::warning(this, "查询失败", "未找到该用户！");
        return;
    }
    // 将信息显示到界面上
    ui->label_name->setText("姓名: " + userInfo["name"].toString());
    ui->label_days->setText("连续学习天数: " + userInfo["learn_days"].toString());
    ui->label_progress->setText("已学单词数: " + userInfo["words_learned"].toString());
}

UserWindow::~UserWindow()
{
    delete ui;
}


